<?php
$servername = "bb-db";
$username = "bb-labs-user";
$password = "bb-labs-password";
$dbname = "bb-labs";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Query to get all tables
$sql = "SHOW TABLES";
$result = $conn->query($sql);

// Check if tables are found
if ($result->num_rows > 0) {
    // Output data of each table
    while($row = $result->fetch_array(MYSQLI_NUM)) {
        $tableName = $row[0];
        echo "<h2>Table: $tableName</h2>";

        // Query to get all rows from the table
        $tableSql = "SELECT * FROM `$tableName`";
        $tableResult = $conn->query($tableSql);

        // Check if rows are found
        if ($tableResult->num_rows > 0) {
            // Output data of each row
            echo "<table border='1'><tr>";
            
            // Output column headers
            $fields = $tableResult->fetch_fields();
            foreach ($fields as $field) {
                echo "<th>" . htmlspecialchars($field->name) . "</th>";
            }
            echo "</tr>";

            // Output data rows
            while ($row = $tableResult->fetch_assoc()) {
                echo "<tr>";
                foreach ($row as $value) {
                    echo "<td>" . htmlspecialchars($value) . "</td>";
                }
                echo "</tr>";
            }
            echo "</table>";
        } else {
            echo "No data found in table $tableName";
        }
    }
} else {
    echo "No tables found";
}

// Close connection
$conn->close();
?>
