<?php
require '../db.php';
session_start(); // Ensure sessions are started

// Check if the page is already completed
if (isset($_SESSION['completed_pages']['e0x02']) && $_SESSION['completed_pages']['e0x02'] === true) {
    header('Location: ../index.php');
    exit;
}

// Initialize score if not already set
if (!isset($_SESSION["score"])) {
    $_SESSION["score"] = 0;
}

// Handle form submission and score update
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $account = $_POST['account'] ?? '';

    if ($account === '1008') {
        // Correct answer, update score and mark page as completed
        $_SESSION["score"] += 1;
        $_SESSION['completed_pages']['e0x02'] = true;
        header('Location: ../index.php');
        exit;
    } else {
        $message = 'Incorrect answer. Try again.';
    }
}

if (!isset($_GET['account'])) {
    header('Location: e0x02.php?account=1009');
    exit;
} else {
    $account = $_GET['account'];
}

// Timer settings
$timer_duration = 300; // 5 minutes in seconds
$timer_expired = false;

if (isset($_SESSION['timer_start'])) {
    $elapsed_time = time() - $_SESSION['timer_start'];
    if ($elapsed_time >= $timer_duration) {
        $timer_expired = true;
        $_SESSION['timer_start'] = time(); // Reset timer for next session
    }
} else {
    $_SESSION['timer_start'] = time();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IDOR 0x02</title>
    <link href="../assets/bootstrap.min.css" rel="stylesheet">
    <link href="../assets/custom.css" rel="stylesheet">
    <style>
        /* Adding background color */
        body {
            background-color: #f0f0f0;
            font-family: Arial, sans-serif;
        }
        /* Adding a background image */
        .background-image {
            background-image: url('assets/authentif(1).jpeg');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            width: 100%;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        /* Content styling */
        .content {
            background: rgba(255, 255, 255, 0.8);
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .timer {
            font-size: 18px;
            color: red;
        }
    </style>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var timerDuration = <?php echo $timer_duration; ?>;
            var timerExpired = <?php echo json_encode($timer_expired); ?>;
            if (timerExpired) {
                document.getElementById('form-container').style.display = 'none';
                document.getElementById('timer').innerText = 'Time expired!';
            } else {
                var endTime = Date.now() + (timerDuration - <?php echo $elapsed_time; ?>) * 1000;
                var timerElement = document.getElementById('timer');
                function updateTimer() {
                    var now = Date.now();
                    var timeLeft = Math.max(0, Math.floor((endTime - now) / 1000));
                    var minutes = Math.floor(timeLeft / 60);
                    var seconds = timeLeft % 60;
                    timerElement.innerText = minutes + ':' + (seconds < 10 ? '0' : '') + seconds;
                    if (timeLeft <= 0) {
                        document.getElementById('form-container').style.display = 'none';
                        timerElement.innerText = 'Time expired!';
                    } else {
                        requestAnimationFrame(updateTimer);
                    }
                }
                updateTimer();
            }
        });
    </script>
</head>
<body>
<img src="../assets/aymax-partner.png" alt="Bootstrap" width="200" height="90">
<main>
    <div class="container px-4 py-5" id="custom-cards">
        <h2 class="pb-2 border-bottom"><a href="../index.php" class="pt-15 fw-bold" style="color:#000000;">Labs</a> / IDOR 0x02</h2>
        <div class="row border-bottom pb-2">
            <div class="pt-20 fw-bold" style="color:#091A32;">
                <p class="no-margin">Your current score: <?php echo $_SESSION["score"]; ?></p>
            </div>
            <div class="col text-end">
                <a href="/capstone/index.php" class="btn btn-outline-secondary me-2" data-bs-toggle="modal" class="pt-15 fw-bold" style="color:#000000;" data-bs-target="#instructionsModal">Hints</a>
            </div>
        </div>

        <?php if (isset($message)) { ?>
            <div class="alert alert-danger" role="alert">
                <p><?php echo $message; ?></p>
            </div>
        <?php } ?>

        <div class="alert alert-warning timer" id="timer">Loading timer...</div>

        <div class="p-5 mb-4 bg-light rounded-3">
            <h2>Your account details</h2>
            <div>
                <?php
                $stmt = $conn->prepare("SELECT * FROM idor0x01 WHERE id = ?");
                $stmt->bind_param("i", $account);
                $stmt->execute();
                $result = $stmt->get_result();
                echo '<hr>';
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo "<p>Username: " . $row["username"] . "</p><p>Address: " . $row["address"] . "</p><p>Type: " . $row["type"] . "</p>";
                    }
                } else {
                    echo "<p>No account information found</p>";
                }
                $conn->close();
                ?>
            </div>
        </div>

        <div id="form-container">
            <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                <div class="mb-3 form-group">
                    <label for="account">Enter account ID for admin :</label>
                    <input type="text" name="account" class="form-control" id="account" required>
                </div>
                <button type="submit" class="btn btn-primary" style="background-color: #79b69e; border-color: #205f6a">Submit</button>
            </form>
        </div>
    </div>

    <div class="modal" id="instructionsModal" tabindex="-1" aria-labelledby="instructionsLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="instructionsModalLabel">Instructions</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <h2>Where to begin</h2>
                    <p>Watch the videos from the course, they will guide you through the labs and let you know which ones are challenges.</p>
                    <p>This course and these labs are primarily focussed on helping you build practical skills. Of course we will provide theory and support along the way but hands-on practice is the only way to get good at BugBounty and Web Application Penetration Testing.</p>
                    <p>You're encouraged to test out other tools and scanners too as you go along!</p>
                    <p>I also encourage you to try out attacks you've learned on different labs (e.g. many of them are vulnerable to XSS, not just the XSS ones)</p>
                    <p>To reset the lab databases, visit /init.php</p>
                    <p>If you have issues, ping us a message on discord!</p>
                    <hr>
                    <p>Good luck!</p>
                </div>
            </div>
        </div>
    </div>
</main>
<script src="../assets/popper.min.js"></script>
<script src="../assets/bootstrap.min.js"></script>
</body>
</html>
