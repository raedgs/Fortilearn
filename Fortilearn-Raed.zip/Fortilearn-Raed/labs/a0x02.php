<?php
// Start the session to keep track of the user's score
session_start();
// Check if the page is already completed
//if (isset($_SESSION['completed_pages']['a0x02']) && $_SESSION['completed_pages']['a0x02'] === true) {
  //  echo "You have already completed this challenge AUthentication 2.";
    //exit;
//}
// Existing logic for a0x02.php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Your existing code here
    
    if ($some_condition_for_success) {
        $_SESSION["score"] += 1; // Increment the score
        $_SESSION['completed_labs']['a0x02'] = true; // Mark as completed
        $status = 1;
        $complete = 1;
    }
}

require '../db.php';

// Initialize score if not already set
if (!isset($_SESSION["score"])) {
    $_SESSION["score"] = 0;
}


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST["mfa"]) && isset($_POST["username2"])) {
        // Check if the MFA code is correct
        $mfa = $_POST["mfa"];
        $username = $_POST["username2"];
        $sql = "SELECT mfa FROM auth0x02 WHERE username = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                if ($row['mfa'] == $mfa) {
                    $message = "You have successfully logged in!";
                    $_SESSION["score"] += 1; // Increment the score
                    $_SESSION['completed_pages']['a0x02'] = true; // Mark as completed
                    $status = 1;
                    $complete = 1;
                }
            }
        } else {
            $message = "Incorrect MFA code";
            $status = 2;
        }
    } else {
        $username = $_POST["username"];
        $password = $_POST["password"];
        $status = 0;

        if ($username === "jessamy" && $password === "pasta") {
            $message = "Please enter your MFA code. Your code can be <a href='a0x02code.php' target='_blank'>found here</a>.";
            $status = 1;

            // Generate a 6-digit code & insert it into the DB
            $code = mt_rand(100000, 999999);
            $stmt = $conn->prepare("UPDATE auth0x02 SET mfa = ? WHERE username = 'jessamy'");
            $stmt->bind_param("s", $code);
            $stmt->execute();
        } else {
            $message = "Your username or password was incorrect!";
            $status = 2;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Authentication 0x02</title>
    <link href="../assets/bootstrap.min.css" rel="stylesheet">
    <link href="../assets/custom.css" rel="stylesheet">
    <style>
        /* Adding background color */
        body {
            background-color: #f0f0f0;
            font-family: Arial, sans-serif;
        }

        /* Adding a background image */
        .background-image {
            background-image: url('assets/authentif(1).jpeg');
            background-size: cover; /* Cover the entire page */
            background-position: center; /* Center the background image */
            background-repeat: no-repeat; /* Do not repeat the background image */
            width: 100%;
            height: 100vh; /* Full viewport height */
            display: flex;
            justify-content: center;
            align-items: center;
        }

        /* Content styling */
        .content {
            background: rgba(255, 255, 255, 0.8); /* White background with transparency */
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        /* Timer styling */
        .timer-container {
            position: absolute;
            top: 20px;
            right: 20px;
            background-color: rgba(0, 0, 0, 0.0);
            color: white;
            padding: 10px;
            border-radius: 5px;
            font-size: 20px;
            font-weight: bold;
        }

        .timer-container.red {
            color: red;
        }
    </style>
</head>

<body>
    <div class="timer-container" id="timer-container">
        <p class="btn btn-outline-secondary me-2" data-bs-toggle="modal" style="color:#000000;" data-bs-target="#instructionsModal">You still have: <span id="timer">05:00</span></p>
        <button id="reset-button" class="btn btn-secondary" style="margin-left: 10px; padding: 5px 10px; font-size: 12px;">Reset Timer</button>
    </div>
    <img src="../assets/aymax-partner.png" alt="Bootstrap" width="200" height="90">
    <main>
        <div class="container px-4 py-5" id="custom-cards">
            <h2 class="pb-2 border-bottom"><a href="../index.php" class="pt-15 fw-bold" style="color:#000000;">Labs</a> / Authentication 02</h2>
            <div class="row border-bottom pb-2">
                <?php
                echo '<div class="pt-20 fw-bold" style="color:#091A32;"><p class="no-margin">Your current score: ' . $_SESSION["score"] . '</p></div>';
                ?>
                <div class="col"></div>
                <div class="col text-end">
                    <a href="/capstone/index.php" class="btn btn-outline-secondary me-2" data-bs-toggle="modal" class="pt-15 fw-bold" style="color:#000000;"
                        data-bs-target="#instructionsModal">Hints</a>
                </div>
            </div>

            <?php if ($errorMessage) { ?>
            <div class="alert alert-danger" role="alert">
                <p><strong>If you just spun up the labs for the first time, this message is normal,</strong> just click
                    the link below or visit /init.php to setup the database
                    and then come back to index.php afterwards.</p>
                <p><a href="../init.php">Click here to reset the database.</a></p>
                <p><?php echo $errorMessage; ?> </p>
                <p>If the issue persists, try rebuilding the application with
                    <code>sudo docker-compose up --build</code>.
                </p>
            </div>
            <?php } ?>

            <?php
            if ($status == 2) {
                echo '<div class="alert alert-danger" role="danger"><p class="no-margin">' . $message . '</p></div>';
            } elseif ($status == 1) {
                echo '<div class="alert alert-success" role="success"><p class="no-margin">' . $message . '</p></div>';
                echo '<div class="alert alert-info" role="info"><p class="no-margin">Your current score: ' . $_SESSION["score"] . '</p></div>';
            }
            ?>

            <div class="alert alert-warning" role="alert">
                <p class="no-margin">Target account: jeremy</p>
                <p class="no-margin">Your credentials: jessamy:pasta</p>
            </div>

            <div class="p-5 mb-4 bg-light rounded-3">
                <?php if ($complete == 1) {
                    echo '<h2>Welcome ' . $username . '</h2>';
                } elseif ($status != 1) { ?>
                    <h2>Login</h2>
                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                        <div class="mb-3 form-group">
                            <label for="username">Username</label>
                            <input type="text" name="username" class="form-control" id="username" aria-describedby="emailHelp" placeholder="Enter username">
                        </div>
                        <div class="mb-3 form-group">
                            <label for="password">Password</label>
                            <input type="password" name="password" class="form-control" id="password" placeholder="Password">
                        </div>
                        <div class="mb-3">
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </div>
                    </form>
                <?php } else { ?>
                    <h2>Enter your MFA code:</h2>
                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                        <div class="mb-3 form-group">
                            <label for="username2">Username</label>
                            <input type="text" value="<?php echo $username; ?>" name="username2" class="form-control" id="username2" readonly>
                        </div>
                        <div class="mb-3 form-group">
                            <label for="mfa">MFA</label>
                            <input type="text" name="mfa" class="form-control" id="mfa" placeholder="000000">
                        </div>
                        <div class="mb-3">
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </div>
                    </form>
                <?php } ?>
            </div>
        </div>
        <div class="modal" id="instructionsModal" tabindex="-1" aria-labelledby="instructionsLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="instructionsModalLabel">Need Help?</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <ul>
                            <li>Try to bypass authentication by guessing credentials, capturing requests, etc.</li>
                            <li>View the database to see if you can change passwords and log in with different accounts.</li>
                            <li>Attempt to capture requests to try and reuse the mfa token</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <script src="../assets/popper.min.js"></script>
    <script src="../assets/bootstrap.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Set the initial time (5 minutes in seconds)
            var timeInSeconds = 5 * 60;

            // Check if there's a stored timer value
            if (localStorage.getItem('timeInSeconds')) {
                timeInSeconds = parseInt(localStorage.getItem('timeInSeconds'), 10);
            }

            // Function to format time as MM:SS
            function formatTime(seconds) {
                var minutes = Math.floor(seconds / 60);
                var secs = seconds % 60;
                return (minutes < 10 ? '0' : '') + minutes + ':' + (secs < 10 ? '0' : '') + secs;
            }

            // Function to update the timer
            function updateTimer() {
                var timerElement = document.getElementById('timer');
                var timerContainer = document.getElementById('timer-container');

                if (timeInSeconds <= 0) {
                    timerElement.innerHTML = '00:00';
                    clearInterval(timerInterval);
                    // Decrease the score and restart the timer
                    var xhr = new XMLHttpRequest();
                    xhr.open('POST', 'update_score.php', true);
                    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
                    xhr.send('action=decreaseScore');
                    timeInSeconds = 5 * 60; // Reset to 5 minutes
                    localStorage.setItem('timeInSeconds', timeInSeconds);
                    timerInterval = setInterval(updateTimer, 1000); // Restart timer
                    return;
                }

                if (timeInSeconds <= 60) {
                    timerContainer.classList.add('red');
                } else {
                    timerContainer.classList.remove('red');
                }
                
                timerElement.innerHTML = formatTime(timeInSeconds);
                timeInSeconds--;
                localStorage.setItem('timeInSeconds', timeInSeconds);
            }

            // Update the timer every second
            var timerInterval = setInterval(updateTimer, 1000);

            // Handle the reset button click
            document.getElementById('reset-button').addEventListener('click', function() {
                timeInSeconds = 5 * 60; // Reset to 5 minutes
                localStorage.setItem('timeInSeconds', timeInSeconds);
                clearInterval(timerInterval);
                timerInterval = setInterval(updateTimer, 1000);
            });
        });
    </script>
</body>

</html>
