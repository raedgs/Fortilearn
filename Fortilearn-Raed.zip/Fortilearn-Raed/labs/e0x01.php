<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>XXE 0x01</title>
    <link href="../assets/bootstrap.min.css" rel="stylesheet">
    <link href="../assets/custom.css" rel="stylesheet">
</head>

<body>
 <img src="../assets/aymax-partner.png" alt="Bootstrap" width="200" height="90">
    <main>
        <div class="container px-4 py-5" id="custom-cards">
            <h2 class="pb-2 border-bottom"><a href="../index.php" class="pt-15 fw-bold" style="color:#000000;">Labs</a> / XXE 0x01</h2>

            <div class="p-5 mb-4 bg-light rounded-3">
                <h2>Bulk user update</h2>
                <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post"
                    enctype="multipart/form-data">
                    <div class="mb-3">
                        <label for="formFile" class="form-label">Upload an XML file with the structure:<br>
                            &lt;creds&gt; &lt;user&gt;username&lt;/user&gt; &lt;password&gt;password&lt;/password&gt;
                            &lt;/creds&gt;
                        </label>
                        <input class="form-control" type="file" id="formFile" name="uploaded_file">
                    </div>
                    <div class="mb-3">
                        <button class=" btn btn-outline-secondary" type="submit">Upload</button>
                    </div>
                </form>

                <div>
                    <?php
                    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                        if (isset($_FILES['uploaded_file'])) {
                            $errors = array();
                            $file_name = $_FILES['uploaded_file']['name'];
                            $file_size = $_FILES['uploaded_file']['size'];
                            $file_tmp = $_FILES['uploaded_file']['tmp_name'];
                            $file_type = $_FILES['uploaded_file']['type'];
                            $file_ext = strtolower(end(explode('.', $_FILES['uploaded_file']['name'])));

                            $extensions = array("xml");

                            if (in_array($file_ext, $extensions) === false) {
                                $errors[] = "Extension not allowed, please choose an XML file.";
                            }

                            if (empty($errors) == true) {
                                libxml_disable_entity_loader(false); // vulnerable setting
                                $xmlfile = file_get_contents($file_tmp);
                                $dom = new DOMDocument();
                                $dom->loadXML($xmlfile, LIBXML_NOENT | LIBXML_DTDLOAD);
                                $creds = simplexml_import_dom($dom);
                                $user = $creds->user;
                                $password = $creds->password;

                                echo "<h2>File uploaded and parsed successfully:</h2>";
                                echo "User: $user <br>";
                                echo "Password: $password";
                            } else {
                                print_r($errors);
                            }
                        }
                    }
                    ?>
                </div>

            </div>
        </div>
         <div class="modal" id="instructionsModal" tabindex="-1" aria-labelledby="instructionsLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="instructionsModalLabel">Instructions</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <h2>Where to begin</h2>
                        <p>Watch the videos from the course, they will guide you through the labs and let you know
                            which ones are challenges.</p>
                        <p>This course and these labs are primarily focussed on helping you build practical skills.
                            Of
                            course we will provide theory and support along the way but hands-on practice is the
                            only
                            way to get good at BugBounty and Web Application Penetration Testing.</p>
                        <p>You're encouraged to test out other tools and scanners too as you go along!</p>
                        <p>I also encorage you to try out attacks you've learned on different labs (e.g. many of
                            them
                            are vulnerable to XSS, not just the XSS ones)</p>
                        <p>To reset the lab databases, visit /init.php</p>
                        <p>If you have issues, ping us a message on discord!</p>
                        <hr>
                        <p>Good luck!</p>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <script src="../assets/popper.min.js"></script>
    <script src="../assets/bootstrap.min.js"></script>
</body>

</html>
