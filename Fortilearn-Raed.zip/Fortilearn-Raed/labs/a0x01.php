<?php
// Start the session
session_start();

// Check if the user has already completed this page
if (isset($_SESSION['completed_pages']['a0x01']) && $_SESSION['completed_pages']['a0x01'] === true) {
    echo "You have already completed this challenge Authentication 1.";
    exit;
}

require '../db.php';

// Initialize score if it's not set
if (!isset($_SESSION["score"])) {
    $_SESSION["score"] = 0;
}

// Store the status to handle redirection after processing the form
$status = 0;

// Check for form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $password = $_POST["password"];

    if ($username === "admin" && $password === "12345") {
        $message = "You have successfully logged in!";
        $_SESSION["score"] += 1; // Increment the score
        $status = 1; // Correct login

        // Set session variable to mark the page as completed
        $_SESSION['completed_pages']['a0x01'] = true;

        // Output JavaScript to handle redirection
        echo "<script>window.onload = function() { window.location.href = '../index.php'; };</script>";
        exit(); // Ensure no further processing
    } else {
        $message = "Your username or password was incorrect!";
        $status = 2; // Incorrect login
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Authentication 0x01</title>
    <link href="../assets/bootstrap.min.css" rel="stylesheet">
    <link href="../assets/custom.css" rel="stylesheet">
    <style>
        /* Adding background color */
        body {
            background-color: #f0f0f0;
            font-family: Arial, sans-serif;
        }

        /* Adding a background image */
        .background-image {
            background-image: url('assets/authentif(1).jpeg');
            background-size: cover; /* Cover the entire page */
            background-position: center; /* Center the background image */
            background-repeat: no-repeat; /* Do not repeat the background image */
            width: 100%;
            height: 100vh; /* Full viewport height */
            display: flex;
            justify-content: center;
            align-items: center;
        }

        /* Content styling */
        .content {
            background: rgba(255, 255, 255, 0.8); /* White background with transparency */
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        /* Timer styling */
        .timer-container {
            position: absolute;
            top: 20px;
            right: 20px;
            background-color: rgba(0, 0, 0, 0.0);
            color: white;
            padding: 10px;
            border-radius: 5px;
            font-size: 20px;
            font-weight: bold;
        }

        .timer-container.red {
            color: red;
        }
    </style>
</head>

<body>
    <div class="timer-container" id="timer-container">
        <p class="btn btn-outline-secondary me-2" data-bs-toggle="modal" style="color:#000000;" data-bs-target="#instructionsModal">  <span id="timer">05:00</span></p>
    </div>
    <div class="container">
        <img src="../assets/aymax-partner.png" alt="Bootstrap" width="200" height="90">
        <main>
            <div class="container px-4 py-5" id="custom-cards">
                <h2 class="pb-2 border-bottom"><a href="../index.php" class="pt-15 fw-bold" style="color:#000000;">Labs</a> / Authentication 1</h2>
                
                <div class="row border-bottom pb-2">
                    <?php
                    echo '<div class="pt-20 fw-bold" style="color:#091A32;"><p class="no-margin">Your current score: ' . $_SESSION["score"] . '</p></div>';
                    ?>
                    <div class="col"></div>
                    <div class="col text-end">
                        <a href="/capstone/index.php" class="btn btn-outline-secondary me-2" data-bs-toggle="modal" style="color:#000000;" data-bs-target="#instructionsModal">Hints</a>
                    </div>
                </div>

                <?php if (isset($errorMessage)) { ?>
                <div class="alert alert-danger" role="alert">
                    <p><strong>If you just spun up the labs for the first time, this message is normal,</strong> just click
                        the link below or visit /init.php to setup the database
                        and then come back to index.php afterwards.</p>
                    <p><a href="../init.php">Click here to reset the database.</a></p>
                    <p><?php echo $errorMessage; ?> </p>
                    <p>If the issue persists, try rebuilding the application with
                        <code>sudo docker-compose up --build</code>.
                    </p>
                </div>
                <?php } ?>

                <div class="alert alert-warning" role="alert">
                    <p class="no-margin">Target account: admin</p>
                </div>

                <?php
                if ($status == 2) {
                    echo '<div class="alert alert-danger" role="danger"><p class="no-margin">' . $message . '</p></div>';
                } elseif ($status == 1) {
                    echo '<div class="alert alert-success" role="success"><p class="no-margin">' . $message . '</p></div>';
                    echo '<div class="alert alert-info" role="info"><p class="no-margin">Your current score: ' . $_SESSION["score"] . '</p></div>';
                }
                ?>

                <?php if (isset($successMessage)) { ?>
                <div class="alert alert-success" role="alert">
                    <p><?php echo $successMessage; ?></p>
                </div>
                <?php } ?>

                <div class="p-5 mb-4 bg-light rounded-3">
                    <h2>Login</h2>
                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                        <div class="mb-3 form-group">
                            <label for="username">Username</label>
                            <input type="text" name="username" class="form-control" id="username" aria-describedby="emailHelp" placeholder="Enter username">
                        </div>
                        <div class="mb-3 form-group">
                            <label for="password">Password</label>
                            <input type="password" name="password" class="form-control" id="password" placeholder="Password">
                        </div>
                        <div class="mb-3">
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
            
            <!-- instructions modal -->
            <div class="modal" id="instructionsModal" tabindex="-1" aria-labelledby="instructionsLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="instructionsModalLabel">Need Help ? </h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <h2>Hello There</h2>
                            <p>In this challenge you need to brute force the password.</p>
                            <p>Don't worry, the password is weak; you can use Burp Suite to make it faster.</p>
                            <p>If you have issues, ping us a message on Discord!</p>
                            <hr>
                            <p>Good luck!</p>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <script src="/assets/popper.min.js"></script>
    <script src="/assets/bootstrap.min.js"></script>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Set the initial time (5 minutes in seconds)
            var timeInSeconds = 5 * 60;

            // Check if there's a stored timer value
            if (localStorage.getItem('timeInSeconds')) {
                timeInSeconds = parseInt(localStorage.getItem('timeInSeconds'), 10);
            }

            // Function to format time as MM:SS
            function formatTime(seconds) {
                var minutes = Math.floor(seconds / 60);
                var secs = seconds % 60;
                return (minutes < 10 ? '0' : '') + minutes + ':' + (secs < 10 ? '0' : '') + secs;
            }

            // Function to update the timer
            function updateTimer() {
                var timerElement = document.getElementById('timer');
                var timerContainer = document.getElementById('timer-container');

                if (timeInSeconds <= 0) {
                    timerElement.innerHTML = '00:00';
                    clearInterval(timerInterval);
                    // Decrease the score and restart the timer
                    var xhr = new XMLHttpRequest();
                    xhr.open('POST', 'update_score.php', true);
                    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
                    xhr.send('action=decreaseScore');
                    timeInSeconds = 5 * 60; // Reset to 5 minutes
                    localStorage.setItem('timeInSeconds', timeInSeconds);
                    timerInterval = setInterval(updateTimer, 1000); // Restart timer
                    return;
                }

                if (timeInSeconds <= 60) {
                    timerContainer.classList.add('red');
                } else {
                    timerContainer.classList.remove('red');
                }
                
                timerElement.innerHTML = formatTime(timeInSeconds);
                timeInSeconds--;
                localStorage.setItem('timeInSeconds', timeInSeconds);
            }

            // Update the timer every second
            var timerInterval = setInterval(updateTimer, 1000);

            // Handle the reset button click
            document.getElementById('reset-button').addEventListener('click', function() {
                timeInSeconds = 5 * 60; // Reset to 5 minutes
                localStorage.setItem('timeInSeconds', timeInSeconds);
                clearInterval(timerInterval);
                timerInterval = setInterval(updateTimer, 1000);
            });
        });
    </script>
</body>

</html>
