<?php
require '../db.php';
session_start();

// Check if the page is already completed
//if (isset($_SESSION['completed_pages']['a0x03']) && $_SESSION['completed_pages']['a0x03'] === true) {
  //  echo "You have already completed this challenge Authentication 0x03.";
    //exit;
//}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $password = $_POST["password"];
    $status = 0;

    $stmt = $conn->prepare("SELECT * FROM auth0x03 WHERE username = ?");
    $stmt->bind_param("s", $username);

    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        // Check if account is locked
        if ($row['lockout_count'] < 5) {
            // Check password
            if ($password === $row['password']) {
                $message = 'Successfully logged in! Challenge complete!';
                $status = 1;
                // Increase score by 2
                $_SESSION["score"] += 2;
                // Mark the challenge as complete
                $_SESSION['completed_pages']['a0x03'] = true;
                // Redirect after successful login
               // header('Location: index.php');
                //exit();
            } else {
                // Password incorrect, add an incorrect attempt
                $stmt = $conn->prepare("UPDATE auth0x03 SET lockout_count = lockout_count + 1 WHERE username = ?");
                $stmt->bind_param("s", $username);
                $stmt->execute();

                if ($stmt->affected_rows === 0) {
                    echo "There was a db error.";
                } else {
                    $message = 'Password incorrect, added a lockout attempt';
                    $status = 2;
                }
            }
        } else {
            $message = 'That account is locked!';
            $status = 2;
        }
    }
    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Authentication 0x03</title>
    <link href="../assets/bootstrap.min.css" rel="stylesheet">
    <link href="../assets/custom.css" rel="stylesheet">
    <style>
        /* Adding background color */
        body {
            background-color: #f0f0f0;
            font-family: Arial, sans-serif;
        }

        /* Adding a background image */
        .background-image {
            background-image: url('assets/authentif(1).jpeg');
            background-size: cover; /* Cover the entire page */
            background-position: center; /* Center the background image */
            background-repeat: no-repeat; /* Do not repeat the background image */
            width: 100%;
            height: 100vh; /* Full viewport height */
            display: flex;
            justify-content: center;
            align-items: center;
        }

        /* Content styling */
        .content {
            background: rgba(255, 255, 255, 0.8); /* White background with transparency */
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        #timer-container {
            text-align: center;
            margin-bottom: 20px;
        }
    </style>
</head>

<body>
    <img src="../assets/aymax-partner.png" alt="Bootstrap" width="200" height="90">
    <main>
        <div class="container px-4 py-5" id="custom-cards">
            <h2 class="pb-2 border-bottom"><a href="../index.php " class="pt-15 fw-bold" style="color:#000000;">Labs</a> / Authentication 0x03 [Challenge]</h2>
            <div class="row border-bottom pb-2">
                <?php
                echo '<div class="pt-20 fw-bold" style="color:#091A32;"><p class="no-margin">Your current score: ' . $_SESSION["score"] . '</p></div>';
                ?>
                <div class="col"></div>
                <div class="col text-end">
                    <a href="/capstone/index.php" class="btn btn-outline-secondary me-2" data-bs-toggle="modal" class="pt-15 fw-bold" style="color:#000000;" data-bs-target="#instructionsModal">Hints</a>
                </div>
            </div>

            <?php if ($errorMessage) { ?>
                <div class="alert alert-danger" role="alert">
                    <p><strong>If you just spun up the labs for the first time, this message is normal,</strong> just click the link below or visit /init.php to setup the database and then come back to index.php afterwards.</p>
                    <p><a href="../init.php">Click here to reset the database.</a></p>
                    <p><?php echo $errorMessage; ?> </p>
                    <p>If the issue persists, try rebuilding the application with <code>sudo docker-compose up --build</code>.</p>
                </div>
            <?php } ?>

            <div class="alert alert-warning" role="alert">
                <p class="no-margin">Target account: admin</p>
            </div>

            <?php
            if ($status == 2) {
                echo '<div class="alert alert-danger" role="danger"><p class="no-margin">' . $message . '</p></div>';
            } elseif ($status == 1) {
                echo '<div class="alert alert-success" role="success"><p class="no-margin">' . $message . '</p></div>';
                echo '<div class="alert alert-info" role="info"><p class="no-margin">Your current score: ' . $_SESSION["score"] . '</p></div>';
            }
            ?>

            <div class="alert alert-warning" role="alert">
                <p class="no-margin">Warning: Accounts will lock after 5 failed login attempts! (You can reset the db at /init.php if needed)</p>
            </div>

            <div id="timer-container">
                <p>Time remaining: <span id="timer">05:00</span></p>
            </div>

            <div class="p-5 mb-4 bg-light rounded-3">
                <div class="row">
                    <div class="col">
                        <img src="../assets/teashoplogo.png" style="max-width: 575px">
                    </div>
                    <div class="col">
                        <h2>Welcome to the Teashop</h2>
                        <p>Welcome to our online tea shop! As passionate purveyors of tea, we've traversed the lush, fragrant tea gardens of the world to bring you an outstanding collection of the finest teas.</p>
                        <p>From the robust flavors of traditional black teas to the subtle complexities of rare white teas, and from the exotic allure of our blooming teas to the soothing charm of our herbal blends, we offer a symphony of tastes sure to delight every tea lover. Step into our store, and let the journey of discovery and enjoyment begin.</p>
                        <p>Immerse yourself in the world of tea!</p>
                        <h2>Login</h2>
                        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                            <div class="mb-3 form-group">
                                <label for="username">Username</label>
                                <input type="text" name="username" class="form-control" id="username" aria-describedby="emailHelp" placeholder="Enter username">
                            </div>
                            <div class="mb-3 form-group">
                                <label for="password">Password</label>
                                <input type="password" name="password" class="form-control" id="password" placeholder="Enter password">
                            </div>
                            <div class="mb-3">
                                <button type="submit" class="btn btn-primary" style="background-color: #79b69e; border-color: #205f6a">Submit</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal" id="instructionsModal" tabindex="-1" aria-labelledby="instructionsLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="instructionsModalLabel">Need Help ? </h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <h2>Hello There</h2>
                        <p>You have only 5 attempts to login with 0 information <b>burpsuit</b></p>
                        <p>is your friend in this challenge</p>
                        <p>If you have issues, ping us a message on discord!</p>
                        <hr>
                        <p>Good luck!</p>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <script src="../assets/popper.min.js"></script>
    <script src="../assets/bootstrap.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Set the initial time (5 minutes in seconds)
            var timeInSeconds = 5 * 60;

            // Function to format time as MM:SS
            function formatTime(seconds) {
                var minutes = Math.floor(seconds / 60);
                var secs = seconds % 60;
                return (minutes < 10 ? '0' : '') + minutes + ':' + (secs < 10 ? '0' : '') + secs;
            }

            // Function to update the timer
            function updateTimer() {
                var timerElement = document.getElementById('timer');

                if (timeInSeconds <= 0) {
                    timerElement.innerHTML = '00:00';
                    clearInterval(timerInterval);
                    // Decrease the score and redirect
                    var xhr = new XMLHttpRequest();
                    xhr.open('POST', 'update_score.php', true);
                    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
                    xhr.send('action=decreaseScore');
                    window.location.href = 'index.php'; // Redirect to index.php
                    return;
                }

                timerElement.innerHTML = formatTime(timeInSeconds);
                timeInSeconds--;
            }

            // Update the timer every second
            var timerInterval = setInterval(updateTimer, 1000);
        });
    </script>
</body>

</html>
