<?php
session_start();
require '../db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['action']) && $_POST['action'] === 'decreaseScore') {
        if (isset($_SESSION["score"]) && $_SESSION["score"] > 0) {
            $_SESSION["score"] -= 1;
        }
    }
}
?>
