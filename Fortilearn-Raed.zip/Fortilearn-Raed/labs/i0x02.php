<?php
require '../db.php';

$showLogin = true;
$showInvalidLogin = false;
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $password = $_POST["password"];

    $sql = "SELECT * FROM injection0x02 WHERE username = ? and password = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $username, $password);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // set a cookie & reload the page
        $cookie = md5($username);
        setcookie("session", $cookie, time() + 3600);
        $page = $_SERVER['PHP_SELF'];
        header("Refresh: 0; url=$page");
    } else {
        $showInvalidLogin = true;
    }
    $stmt->close();
}

// check session cookie
if ($_COOKIE['session']) {
    // echo $_COOKIE['session'];
    $cookie = $_COOKIE['session'];

    $sql = "SELECT * FROM injection0x02 WHERE session = '$cookie'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $showLogin = false;
    }
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Injection 0x02</title>
    <link href="../assets/bootstrap.min.css" rel="stylesheet">
    <link href="../assets/custom.css" rel="stylesheet">
    <style>
        /* Adding background color */
        body {
            background-color: #f0f0f0;;
            font-family: Arial, sans-serif;
        }

        /* Adding a background image */
        .background-image {
            background-image: url('assets/authentif(1).jpeg');
            background-size: cover; /* Cover the entire page */
            background-position: center; /* Center the background image */
            background-repeat: no-repeat; /* Do not repeat the background image */
            width: 100%;
            height: 100vh; /* Full viewport height */
            display: flex;
            justify-content: center;
            align-items: center;
        }

        /* Content styling */
        .content {
            background: rgba(255, 255, 255, 0.8); /* White background with transparency */
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
    </style>
</head>

<body>
    <main>
        <div class="container px-4 py-5" id="custom-cards">
            <h2 class="pb-2 border-bottom"><a href="../index.php"class="pt-15 fw-bold" style="color:#000000;">Labs</a> / Injection 0x02</h2>
             <div class="row border-bottom pb-2"><?php
          
               
                echo '<div class="pt-20 fw-bold" style="color:#091A32;"><p class="no-margin">Your current score: ' . $_SESSION["score"] . '</p></div>';
            
            ?>
                <div class="col">   
                    
                    
                </div>
                <div class="col text-end">
                
                    <a href="/capstone/index.php" class="btn btn-outline-secondary me-2" data-bs-toggle="modal" class="pt-15 fw-bold" style="color:#000000;"
                        data-bs-target="#instructionsModal">Hints</a>
                </div>
            </div>

            <?php if ($errorMessage) { ?>
            <div class="alert alert-danger" role="alert">
                <p><strong>If you just spun up the labs for the first time, this message is normal,</strong> just click
                    the link below or visit /init.php to setup the database
                    and then come back to index.php afterwards.</p>
                <p><a href="../init.php">Click here to reset the database.</a></p>
                <p><?php echo $errorMessage; ?> </p>
                <p>If the issue persists, try rebuilding the application with
                    <code>sudo docker-compose up --build</code>.
                </p>
               
            </div>
            <?php } ?>

            

    

            <?php
            if ($status == 2) {
                echo '<div class="alert alert-danger" role="danger"><p class="no-margin">' . $message . '</p></div>';
            } elseif ($status == 1) {
                echo '<div class="alert alert-success" role="success"><p class="no-margin">' . $message . '</p></div>';
                echo '<div class="alert alert-info" role="info"><p class="no-margin">Your current score: ' . $_SESSION["score"] . '</p></div>';
            }
            ?>
             
            <?php if ($successMessage) { ?>
            <div class="alert alert-success" role="alert">
                <p><?php echo $successMessage; ?></p>
                
            </div>
            
            <?php } ?>
            

            <div class="alert alert-warning" role="alert">
                <p class='no-margin'>Default credentials: jeremy:jeremy</p>
            </div>

            <div class="p-5 mb-4 bg-light rounded-3">
                <div>
                    <?php
                    if ($showInvalidLogin == true) { ?>
                        <div class="alert alert-danger" role="alert">
                            <p class='no-margin'>Invalid credentials</p>
                        </div>
                    <?php } ?>
                    <?php if ($showLogin == true) { ?>
                        <h2>Login</h2>
                        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="username" class="sr-only">Username</label>
                                    <input type="text" name="username" class="form-control" id="username" placeholder="Username">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="password" class="sr-only">Password</label>
                                    <input type="password" name="password" class="form-control" id="password" placeholder="Password">
                                </div>
                            </div>
                            <button type="submit" class="btn btn-primary mb-2">Log in</button>
                        </form>
                    <?php } else { ?>
                        <h2>Welcome to your dashboard!</h2>
                    <?php } ?>
                </div>

            </div>
        </div>
        <div class="modal" id="instructionsModal" tabindex="-1" aria-labelledby="instructionsLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="instructionsModalLabel">Instructions</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <h2>Where to begin</h2>
                        <p>Watch the videos from the course, they will guide you through the labs and let you know
                            which ones are challenges.</p>
                        <p>This course and these labs are primarily focussed on helping you build practical skills.
                            Of
                            course we will provide theory and support along the way but hands-on practice is the
                            only
                            way to get good at BugBounty and Web Application Penetration Testing.</p>
                        <p>You're encouraged to test out other tools and scanners too as you go along!</p>
                        <p>I also encorage you to try out attacks you've learned on different labs (e.g. many of
                            them
                            are vulnerable to XSS, not just the XSS ones)</p>
                        <p>To reset the lab databases, visit /init.php</p>
                        <p>If you have issues, ping us a message on discord!</p>
                        <hr>
                        <p>Good luck!</p>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <script src="../assets/popper.min.js"></script>
    <script src="../assets/bootstrap.min.js"></script>
</body>

</html>
