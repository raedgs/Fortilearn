<?php
session_start();

// Define valid users with their corresponding passwords
$valid_users = [
    'raed' => '1234',
    'mami' => '1234',
    'user3' => 'password3',
    'user4' => 'password4'
];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Check if the username exists and the password matches
    if (array_key_exists($username, $valid_users) && $valid_users[$username] === $password) {
        $_SESSION['loggedin'] = true;
        $_SESSION['username'] = $username;

        // Redirect to index.php
        header("Location: index.php");
        exit();
    } else {
        echo "Invalid username or password";
    }
}
?>
