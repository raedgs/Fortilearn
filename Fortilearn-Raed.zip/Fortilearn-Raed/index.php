<?php
session_start();

require 'db.php';
require 'checks.php';

if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: index.php");
    exit();
}

if (!isset($_SESSION['points'])) {
    $_SESSION['points'] = 0;
}

if ($answer_is_correct) {
    $_SESSION['accessed_pages']['a0x01'] = true; // Track that this page was accessed
    header("Location: a0x01.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['reset_challenge'])) {
    // Reset the completion status for a0x01
    unset($_SESSION['completed_pages']['a0x01']);

    // Initialize completed labs array if not already set
    if (!isset($_SESSION['completed_labs'])) {
        $_SESSION['completed_labs'] = [];
    }

    // Handle the request to reset all labs
    if (isset($_POST['reset_all_labs'])) {
        // Reset the completed labs array
        $_SESSION['completed_labs'] = [];
        
        // Optionally set a message or redirect
        header('Location: index.php'); // Redirect to avoid form resubmission
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <title>FortiLearn</title>
     <link  rel="icon" href="nn.png" type="image/png" >
    <link href="assets/bootstrap.min.css" rel="stylesheet">
    <link href="assets/custom.css" rel="stylesheet">
    <style>
        body {
            background-color: #f0f0f0; /* Light gray background color */
            margin: 0;
            font-family: Arial, sans-serif;
        }

        /* Top bar styling */
        .top-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: #333;
            color: white;
            padding: 10px 20px;
        }

        .top-bar .logo img {
            height: 50px;
        }

        .top-bar .welcome-message {
            display: flex;
            align-items: center;
        }

        .top-bar .welcome-message h1 {
            margin: 0;
            font-size: 18px;
        }

        .top-bar .logout-form button {
            background-color: #ff4d4d;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
        }

        .top-bar .logout-form button:hover {
            background-color: #e60000;
        }
         .header {
            display: flex;
            align-items: center;
            background-color: #e0e0e0;
            padding: 20px;
            margin-bottom: 20px;
        }

        .header .header-image {
            width: 60px;
            height: 60px;
            margin-right: 20px;
        }

        .header .header-title {
            font-size: 24px;
            font-weight: bold;
        }


        .background-image {
            background-image: url('https://example.com/path/to/your/image.jpg'); /* Replace with your background image URL */
            background-size: cover; /* Cover the entire page */
            background-position: center; /* Center the background image */
            background-repeat: no-repeat; /* Do not repeat the background image */
            width: 100%;
            height: calc(100vh - 60px); /* Full viewport height minus top bar height */
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .content {
            background: rgba(255, 255, 255, 0.8); /* White background with transparency */
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .content img {
            display: inline-block;
            margin-left: 20px;
            margin-top: 20px;
        }
    </style>
</head>
<body>

    <!-- Top bar with logo, welcome message, and logout button -->
    <div class="top-bar">
      <div class="logo">
            <img src="assets/aymax-partner.png" alt="Logo">
        </div>
        <div class="welcome-message">
            <h1>Welcome, <b><?php echo $_SESSION['username']; ?></b> enjoy Hacking ! </h1>
        </div>
      
        <div class="logout-form">
            <form method="POST" action="index.html"> <!-- Ensure this points to your logout script -->
                <button type="submit">Logout</button>
            </form>
        </div>
    </div>

 

</body>

 
   
    

     
    <main>
        <div class="container px-4 py-5" id="custom-cards" >
            <div class="row border-bottom pb-2"><?php
          
               
                echo '<div class="pt-20 fw-bold" style="color:#091A32;"><p class="no-margin">Your current score: ' . $_SESSION["score"] . '</p></div>';
            
            ?>
                <div class="col">   
                    
                    
                </div>
                <div class="col text-end">
                
            
                </div>
            </div>

            <?php if ($errorMessage) { ?>
            <div class="alert alert-danger" role="alert">
                <p><strong>If you just spun up the labs for the first time, this message is normal,</strong> just click
                    the link below or visit /init.php to setup the database
                    and then come back to index.php afterwards.</p>
                <p><a href="../init.php">Click here to reset the database.</a></p>
                <p><?php echo $errorMessage; ?> </p>
                <p>If the issue persists, try rebuilding the application with
                    <code>sudo docker-compose up --build</code>.
                </p>
               
            </div>
            <?php } ?>

            <?php if ($successMessage) { ?>
            <div class="alert alert-success" role="alert">
                <p><?php echo $successMessage; ?></p>
                
            </div>
            
            <?php } ?>
             <h1 class="h1-index">choose some cards and try to get the right answer</h1>
            
            <h2 class="h1-index">Authentication & Authorization Attacks</h2>
            <!-- Authentication & Authorization -->
            <div class="row row-cols-1 row-cols-lg-3 align-items-stretch g-4 py-5">
                <div class="col"> 
                    <div class="card card-cover  h-100 overflow-hidden text-white bg-dark rounded-5 shadow-lg" 
                        id="card15" style="background-image: url('assets/authentif(1).jpeg');background-repeat: no-repeat">
                        <div class="d-flex flex-column h-100 p-5 pb-3 text-shadow-1"><h4 class="pt-15 fw-bold">Auth 1</h4>
                      
                       
                            
                            <ul class="d-flex list-unstyled mt-auto">
                                <li class="me-auto">
                                    
                                     <h4 class="pt-15 fw-bold"> 1 pts </h4>
                                </li>
                                <li class="d-flex align-items-center me-3">
                                    <svg class="bi me-2" width="1em" height="1em">
                                        <use xlink:href="#geo-fill" />
                                    </svg>
                                    <input  type="checkbox" id="checkbox13"
                                        onclick="updateBackground('card13', 'checkbox13')">&nbsp;<a class="pt-15 fw-bold" style="color:#ffffff;"
                                        href='labs/a0x01.php'>Access lab ></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="col">
                    <div class="card card-cover h-100 overflow-hidden text-white bg-dark rounded-5 shadow-lg"
                        id="card15"  height="10" style="background-image: url('assets/authentif(1).jpeg');background-repeat: no-repeat">
                        
                        
                        <div class="d-flex flex-column h-100 p-5 pb-3 text-shadow-1"><h4 class="pt-20 fw-bold">Auth 2</h4>
                         
                            <ul class="d-flex list-unstyled mt-auto">
                                <li class="me-auto">
                                 
                                    <h4 class="pt-15 fw-bold"> 1 pts </h4>
                                </li>
                                <li class="d-flex align-items-center me-3">
                                    <svg class="bi me-2" width="1em" height="1em">
                                        <use xlink:href="#geo-fill" />
                                    </svg>
                                    <input type="checkbox" id="checkbox14"
                                        onclick="updateBackground('card14', 'checkbox14')">&nbsp;<a class="pt-15 fw-bold" style="color:#ffffff;"
                                        href='labs/a0x02.php'>Access lab ></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="col">
                    <div class="card card-cover h-100 overflow-hidden text-white bg-dark rounded-5 shadow-lg"
                        id="card15"  height="10" style="background-image: url('assets/authentif(1).jpeg');background-repeat: no-repeat">
                        <div class="d-flex flex-column h-100 p-5 pb-3 text-shadow-1"><h4 class="pt-20 fw-bold">Auth 3</h4>
                            <h2 class="pt-5 mt-5 mb-4 display-6 lh-1 fw-bold"></h2>
                            <ul class="d-flex list-unstyled mt-auto">
                                <li class="me-auto">
                                 
                                    <h4 class="pt-15 fw-bold"> 1 pts </h4>
                                </li>
                                <li class="d-flex align-items-center me-3">
                                    <svg class="bi me-2" width="1em" height="1em">
                                        <use xlink:href="#geo-fill" />
                                    </svg>
                                    <input type="checkbox" id="checkbox15"
                                        onclick="updateBackground('card15', 'checkbox15')">&nbsp;<a class="pt-15 fw-bold" style="color:#ffffff;"
                                        href='labs/a0x03.php'>Access lab ></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row row-cols-1 row-cols-lg-3 align-items-stretch g-4 py-5">
                <div class="col">
                    <div class="card card-cover h-100 overflow-hidden text-white bg-dark rounded-5 shadow-lg"
                        id="card15"  height="10" style="background-image: url('assets/authentif(1).jpeg');background-repeat: no-repeat">
                        <div class="d-flex flex-column h-100 p-5 pb-3 text-shadow-1"><h4 class="pt-20 fw-bold">Auth 4</h4>
                            <h2 class="pt-5 mt-5 mb-4 display-6 lh-1 fw-bold"></h2>
                            <ul class="d-flex list-unstyled mt-auto">
                                <li class="me-auto">
                                
                                    <h4 class="pt-15 fw-bold"> 2 pts </h4>
                                </li>
                                <li class="d-flex align-items-center me-3">
                                    <svg class="bi me-2" width="1em" height="1em">
                                        <use xlink:href="#geo-fill" />
                                    </svg>
                                    <input type="checkbox" id="checkbox13"
                                        onclick="updateBackground('card13', 'checkbox13')">&nbsp;<a class="pt-15 fw-bold" style="color:#ffffff;"
                                        href='labs/e0x02.php'>Access lab ></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="col">
                    <div class="card card-cover h-100 overflow-hidden text-white bg-dark rounded-5 shadow-lg"
                        id="card15"  height="10" style="background-image: url('assets/authentif(1).jpeg');background-repeat: no-repeat">
                        <div class="d-flex flex-column h-100 p-5 pb-3 text-shadow-1"><h4 class="pt-20 fw-bold">Auth 5</h4>
                            <h2 class="pt-5 mt-5 mb-4 display-6 lh-1 fw-bold"></h2>
                            <ul class="d-flex list-unstyled mt-auto">
                                <li class="me-auto">
                                  
                                    <h4 class="pt-15 fw-bold"> 2 pts </h4>
                                </li>
                                <li class="d-flex align-items-center me-3">
                                    <svg class="bi me-2" width="1em" height="1em">
                                        <use xlink:href="#geo-fill" />
                                    </svg>
                                    <input type="checkbox" id="checkbox14"
                                        onclick="updateBackground('card14', 'checkbox14')">&nbsp;<a class="pt-15 fw-bold" style="color:#ffffff;"
                                        href='labs/api0x01.php'>Access lab ></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="col">
                   <div class="card card-cover h-100 overflow-hidden text-white bg-dark rounded-5 shadow-lg"
                        id="card15"  height="10" style="background-image: url('assets/authentif(1).jpeg');background-repeat: no-repeat">
                        <div class="d-flex flex-column h-100 p-5 pb-3 text-shadow-1"><h4 class="pt-20 fw-bold">Auth 6</h4>
                            <h2 class="pt-5 mt-5 mb-4 display-6 lh-1 fw-bold"></h2>
                            <ul class="d-flex list-unstyled mt-auto">
                                <li class="me-auto">
                              
                                    <h4 class="pt-15 fw-bold"> 3 pts </h4>
                                </li>
                                <li class="d-flex align-items-center me-3">
                                    <svg class="bi me-2" width="1em" height="1em">
                                        <use xlink:href="#geo-fill" />
                                    </svg>
                                    <input type="checkbox" id="checkbox15"
                                        onclick="updateBackground('card15', 'checkbox15')">&nbsp;<a class="pt-15 fw-bold" style="color:#ffffff;"
                                        href='labs/api0x01.php'>Access lab ></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <h1 class="h1-index">Injection Attacks</h1>
            <!-- Injection Attacks -->
            <!-- File inclusion -->
            <div class="row row-cols-1 row-cols-lg-3 align-items-stretch g-4 py-5">
                <div class="col">
                   <div class="card card-cover h-100 overflow-hidden text-white bg-dark rounded-5 shadow-lg"
                        id="card15"  height="10" style="background-image: url('assets/lfii.png');background-repeat: no-repeat">
                        <div class="d-flex flex-column h-100 p-5 pb-3 text-shadow-1"><h4 class="pt-20 fw-bold">File Inclusion 1</h4>
                         
                            <ul class="d-flex list-unstyled mt-auto">
                                <li class="me-auto">
                                 
                                    <h4 class="pt-15 fw-bold"> 1 pts </h4>
                                </li>
                                <li class="d-flex align-items-center me-3">
                                    <svg class="bi me-2" width="1em" height="1em">
                                        <use xlink:href="#geo-fill" />
                                    </svg>
                                    <input type="checkbox" id="checkbox1"
                                        onclick="updateBackground('card1', 'checkbox1')">&nbsp;<a class="pt-15 fw-bold" style="color:#ffffff;"
                                        href='labs/fi0x01.php'>Access lab ></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="col">
                   <div class="card card-cover h-100 overflow-hidden text-white bg-dark rounded-5 shadow-lg"
                        id="card15"  height="10" style="background-image: url('assets/lfii.png');background-repeat: no-repeat">
                        <div class="d-flex flex-column h-100 p-5 pb-3 text-shadow-1"><h4 class="pt-20 fw-bold">File Inclusion 2</h4>
                            
                            <ul class="d-flex list-unstyled mt-auto">
                                <li class="me-auto">
                                  
                                     <h4 class="pt-15 fw-bold"> 2 pts </h4>
                                </li>
                                <li class="d-flex align-items-center me-3">
                                    <svg class="bi me-2" width="1em" height="1em">
                                        <use xlink:href="#geo-fill" />
                                    </svg>
                                    <input type="checkbox" id="checkbox2"
                                        onclick="updateBackground('card2', 'checkbox2')">&nbsp;<a class="pt-15 fw-bold" style="color:#ffffff;"
                                        href='labs/fi0x02.php'>Access lab ></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="col">
                <div class="card card-cover h-100 overflow-hidden text-white bg-dark rounded-5 shadow-lg"
                        id="card15"  height="10" style="background-image: url('assets/lfii.png');background-repeat: no-repeat">
                        <div class="d-flex flex-column h-100 p-5 pb-3 text-shadow-1"><h4 class="pt-20 fw-bold">File Inclusion 3</h4>
                            <h2 class="pt-5 mt-5 mb-4 display-6 lh-1 fw-bold"></h2>
                            <ul class="d-flex list-unstyled mt-auto">
                                <li class="me-auto">
                                  <h2></h2> <h2></h2> 
                                  <h2></h2>
                                     <h4 class="pt-15 fw-bold"> 3 pts </h4>
                                </li>
                                <li class="d-flex align-items-center me-3">
                                    <svg class="bi me-2" width="1em" height="1em">
                                        <use xlink:href="#geo-fill" />
                                    </svg>
                                    <input type="checkbox" id="checkbox3"
                                        onclick="updateBackground('card3', 'checkbox3')">&nbsp;<a class="pt-15 fw-bold" style="color:#ffffff;"
                                        href='labs/fi0x03.php'>Access lab ></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>

            <!-- SQLi -->
            <div class="row row-cols-1 row-cols-lg-3 align-items-stretch g-4 py-5">
                <div class="col">
                    <div class="card card-cover h-100 overflow-hidden text-white bg-dark rounded-5 shadow-lg"
                        id="card15"  height="10" style="background-image: url('assets/sqli(1).png');background-repeat: no-repeat">
                        <div class="d-flex flex-column h-100 p-5 pb-3 text-shadow-1"><h4 class="pt-20 fw-bold">SQL Injection 1</h4>
                          
                            <ul class="d-flex list-unstyled mt-auto">
                                <li class="me-auto">
                               
                                    <h4 class="pt-15 fw-bold"> 1 pts </h4>
                                </li>
                                <li class="d-flex align-items-center me-3">
                                    <svg class="bi me-2" width="1em" height="1em">
                                        <use xlink:href="#geo-fill" />
                                    </svg>
                                    <input type="checkbox" id="checkbox1"
                                        onclick="updateBackground('card1', 'checkbox1')">&nbsp;<a class="pt-15 fw-bold" style="color:#ffffff;"
                                        href='labs/i0x01.php'>Access lab ></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="col">
                    <div class="card card-cover h-100 overflow-hidden text-white bg-dark rounded-5 shadow-lg"
                        id="card15"  height="10" style="background-image: url('assets/sqli(1).png');background-repeat: no-repeat">
                        <div class="d-flex flex-column h-100 p-5 pb-3 text-shadow-1"><h4 class="pt-20 fw-bold">SQL Injection 2</h4>
                            <h2 class="pt-5 mt-5 mb-4 display-6 lh-1 fw-bold"></h2>
                            <ul class="d-flex list-unstyled mt-auto">
                                <li class="me-auto">
                             
                                     <h4 class="pt-15 fw-bold"> 2 pts </h4>
                                </li>
                                <li class="d-flex align-items-center me-3">
                                    <svg class="bi me-2" width="1em" height="1em">
                                        <use xlink:href="#geo-fill" />
                                    </svg>
                                    <input type="checkbox" id="checkbox2"
                                        onclick="updateBackground('card2', 'checkbox2')">&nbsp;<a class="pt-15 fw-bold" style="color:#ffffff;" 
                                        href='labs/i0x02.php'>Access lab ></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
<div class="col">
                  <div class="card card-cover h-100 overflow-hidden text-white bg-dark rounded-5 shadow-lg"
                        id="card15"  height="10" style="background-image: url('assets/sqli(1).png');background-repeat: no-repeat">
                        <div class="d-flex flex-column h-100 p-5 pb-3 text-shadow-1"><h4 class="pt-20 fw-bold">SQL Injection 4</h4>
                            
                            <ul class="d-flex list-unstyled mt-auto">
                                <li class="me-auto">
                              
                                     <h4 class="pt-15 fw-bold"> 3 pts </h4>
                                </li>
                                <li class="d-flex align-items-center me-3">
                                    <svg class="bi me-2" width="1em" height="1em">
                                        <use xlink:href="#geo-fill" />
                                    </svg>
                                    <input type="checkbox" id="checkbox2"
                                        onclick="updateBackground('card2', 'checkbox2')">&nbsp;<a class="pt-15 fw-bold" style="color:#ffffff;"
                                        href='labs/i0x04.php'>Access lab ></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            
            </div>

            <!-- XSS -->
            <div class="row row-cols-1 row-cols-lg-3 align-items-stretch g-4 py-5">
                
                <div class="col">
                 <div class="card card-cover h-100 overflow-hidden text-white bg-dark rounded-5 shadow-lg"
                        id="card15"  height="10" style="background-image: url('assets/xss(1).jpg');background-repeat: no-repeat">
                        <div class="d-flex flex-column h-100 p-5 pb-3 text-shadow-1"><h4 class="pt-20 fw-bold" >XSS 1</h4>
                            <h2 class="pt-5 mt-5 mb-4 display-6 lh-1 fw-bold"></h2>
                            <ul class="d-flex list-unstyled mt-auto">
                                <li class="me-auto">
                                   
                                     <h4 class="pt-15 fw-bold"> 1 pts </h4>
                                </li>
                                <li class="d-flex align-items-center me-3">
                                    <svg class="bi me-2" width="1em" height="1em">
                                        <use xlink:href="#geo-fill" />
                                    </svg>
                                    <input type="checkbox" id="checkbox4"
                                        onclick="updateBackground('card4', 'checkbox4')">&nbsp;<a class="pt-15 fw-bold" style="color:#ffffff;"
                                        href='labs/x0x01.php'>Access lab ></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="col">
                   <div class="card card-cover h-100 overflow-hidden text-white bg-dark rounded-5 shadow-lg"
                        id="card15"  height="10" style="background-image: url('assets/xss(1).jpg');background-repeat: no-repeat">
                        <div class="d-flex flex-column h-100 p-5 pb-3 text-shadow-1"><h4 class="pt-20 fw-bold">XSS 2</h4>
                          
                            <ul class="d-flex list-unstyled mt-auto">
                                <li class="me-auto">
                                   
                                    <h4 class="pt-15 fw-bold"> 2 pts </h4>
                                </li>
                                <li class="d-flex align-items-center me-3">
                                    <svg class="bi me-2" width="1em" height="1em">
                                        <use xlink:href="#geo-fill" />
                                    </svg>
                                    <input type="checkbox" id="checkbox5"
                                        onclick="updateBackground('card5', 'checkbox5')">&nbsp;<a class="pt-15 fw-bold" style="color:#ffffff;"
                                        href='labs/x0x02.php'>Access lab ></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>

<div class="col">
                 <div class="card card-cover h-100 overflow-hidden text-white bg-dark rounded-5 shadow-lg"
                        id="card15"  height="10" style="background-image: url('assets/xss(1).jpg');background-repeat: no-repeat">
                        <div class="d-flex flex-column h-100 p-5 pb-3 text-shadow-1"><h4 class="pt-20 fw-bold">XSS 3</h4>
                  
                            <ul class="d-flex list-unstyled mt-auto">
                                <li class="me-auto">
                                
                                    <h4 class="pt-15 fw-bold"> 3 pts </h4>
                                </li>
                                <li class="d-flex align-items-center me-3">
                                    <svg class="bi me-2" width="1em" height="1em">
                                        <use xlink:href="#geo-fill" />
                                    </svg>
                                    <input type="checkbox" id="checkbox6"
                                        onclick="updateBackground('card6', 'checkbox6')">&nbsp;<a class="pt-15 fw-bold" style="color:#ffffff;"
                                        href='labs/x0x03.php'>Access lab ></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Command inj -->
            <div class="row row-cols-1 row-cols-lg-3 align-items-stretch g-4 py-5">
                
                <div class="col">
                 <div class="card card-cover h-100 overflow-hidden text-white bg-dark rounded-5 shadow-lg"
                        id="card15"  height="10" style="background-image: url('assets/cmdi(2).png');background-repeat: no-repeat">
                        <div class="d-flex flex-column h-100 p-5 pb-3 text-shadow-1"><h4 class="pt-20 fw-bold">Command Injection 1</h4>
                            <h2 class="pt-5 mt-5 mb-4 display-6 lh-1 fw-bold">	</h2>
                            <ul class="d-flex list-unstyled mt-auto">
                                <li class="me-auto">
                                   
                                    <h4 class="pt-15 fw-bold"> 1 pts </h4>
                                </li>
                                <li class="d-flex align-items-center me-3">
                                    <svg class="bi me-2" width="1em" height="1em">
                                        <use xlink:href="#geo-fill" />
                                    </svg>
                                    <input type="checkbox" id="checkbox7"
                                        onclick="updateBackground('card7', 'checkbox7')">&nbsp;<a class="pt-15 fw-bold" style="color:#ffffff;"
                                        href='labs/c0x01.php'>Access lab ></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>


                <div class="col">
                    <div class="card card-cover h-100 overflow-hidden text-white bg-dark rounded-5 shadow-lg"
                        id="card15"  height="10" style="background-image: url('assets/cmdi(2).png');background-repeat: no-repeat">
                        <div class="d-flex flex-column h-100 p-5 pb-3 text-shadow-1"><h4 class="pt-20 fw-bold">Command Injection 2</h4>
                      
                            <ul class="d-flex list-unstyled mt-auto">
                                <li class="me-auto">
                                 
                                      <h4 class="pt-15 fw-bold"> 2 pts </h4>
                                </li>
                                <li class="d-flex align-items-center me-3">
                                    <svg class="bi me-2" width="1em" height="1em">
                                        <use xlink:href="#geo-fill" />
                                    </svg>
                                    <input type="checkbox" id="checkbox8"
                                        onclick="updateBackground('card8', 'checkbox8')">&nbsp;<a class="pt-15 fw-bold" style="color:#ffffff;"
                                        href='labs/c0x02.php'>Access lab ></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col">
                  <div class="card card-cover h-100 overflow-hidden text-white bg-dark rounded-5 shadow-lg"
                        id="card15"  height="10" style="background-image: url('assets/cmdi(2).png');background-repeat: no-repeat">
                        <div class="d-flex flex-column h-100 p-5 pb-3 text-shadow-1"><h4 class="pt-20 fw-bold">Command Injection 3</h4>
                            <h2 class="pt-5 mt-5 mb-4 display-6 lh-1 fw-bold"></h2>
                            <ul class="d-flex list-unstyled mt-auto">
                                <li class="me-auto">
                                 
                                      <h4 class="pt-15 fw-bold"> 3 pts </h4>
                                </li>
                                <li class="d-flex align-items-center me-3">
                                    <svg class="bi me-2" width="1em" height="1em">
                                        <use xlink:href="#geo-fill" />
                                    </svg>
                                    <input type="checkbox" id="checkbox9"
                                        onclick="updateBackground('card9', 'checkbox9')">&nbsp;<a class="pt-15 fw-bold" style="color:#ffffff;"
                                        href='labs/c0x03.php'>Access lab ></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>

            <!-- SSTI & XXE -->
            <div class="row row-cols-1 row-cols-lg-3 align-items-stretch g-4 py-5">
                

                <div class="col">
                   <div class="card card-cover h-100 overflow-hidden text-white bg-dark rounded-5 shadow-lg"
                        id="card15"  height="10" style="background-image: url('assets/ssti.png');background-repeat: no-repeat">
                        <div class="d-flex flex-column h-100 p-5 pb-3 text-shadow-1"><h4 class="pt-20 fw-bold">SSTI 1</h4>
                           <h4 class="pt-20 fw-bold">
                           </h4>
                           <h4 class="pt-20 fw-bold"><h2></h2>	<h2></h2><h2></h2><h2></h2><h2></h2><h2></h2><h2></h2><h2></h2><h2></h2><h2></h2><h2></h2><h2></h2></h4>
                            <ul class="d-flex list-unstyled mt-auto">
                                <li class="me-auto">
                                   
                                    <h4 class="pt-15 fw-bold"> 1 pts </h4>
                                </li>
                                <li class="d-flex align-items-center me-3">
                                    <svg class="bi me-2" width="1em" height="1em">
                                        <use xlink:href="#geo-fill" />
                                    </svg>
                                    <input type="checkbox" id="checkbox16"
                                        onclick="updateBackground('card16', 'checkbox16')">&nbsp;<a class="pt-15 fw-bold" style="color:#ffffff;"
                                        href='http://localhost:81/ssti0x01.php'>Access lab ></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="col">
                    <div class="card card-cover h-100 overflow-hidden text-white bg-dark rounded-5 shadow-lg"
                        id="card17" style="background-image: url('assets/ssti.png');background-repeat: no-repeat">
                        <div class="d-flex flex-column h-100 p-5 pb-3 text-white text-shadow-1"><h4 class="pt-20 fw-bold">SSTI 2</h4>
                         
                            <ul class="d-flex list-unstyled mt-auto">
                                <li class="me-auto">
                                  
                                    <h4 class="pt-15 fw-bold"> 2 pts </h4>
                                </li>
                                <li class="d-flex align-items-center me-3">
                                    <svg class="bi me-2" width="1em" height="1em">
                                        <use xlink:href="#geo-fill" />
                                    </svg>
                                    <input type="checkbox" id="checkbox17"
                                        onclick="updateBackground('card17', 'checkbox17')">&nbsp;<a class="pt-15 fw-bold" style="color:#ffffff;"
                                        href='http://localhost:81/ssti0x02.php'>Access lab ></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>

            <!-- SSRF -->
            <div class="row row-cols-1 row-cols-lg-3 align-items-stretch g-4 py-5">
                <div class="col">
                   <div class="card card-cover h-100 overflow-hidden text-white bg-dark rounded-5 shadow-lg"
                        id="card15"  height="10" style="background-image: url('assets/xxee(4).jpg');background-repeat: no-repeat">
                        <div class="d-flex flex-column h-100 p-5 pb-3 text-shadow-1"><h4 class="pt-20 fw-bold"></h4>
                          
                            <ul class="d-flex list-unstyled mt-auto">
                                <li class="me-auto">
                                   
                                    <h4 class="pt-15 fw-bold"> 3 pts </h4>
                                </li>
                                <li class="d-flex align-items-center me-3">
                                    <svg class="bi me-2" width="1em" height="1em">
                                        <use xlink:href="#geo-fill" />
                                    </svg>
                                    <input type="checkbox" id="checkbox17"
                                        onclick="updateBackground('card17', 'checkbox17')">&nbsp;<a class="pt-15 fw-bold" style="color:#ffffff;"
                                        href='labs/e0x01.php'>Access lab ></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="card card-cover h-100 overflow-hidden text-white bg-dark rounded-5 shadow-lg"
                        id="card15"  height="10" style="background-image: url('assets/ssrff.png');background-repeat: no-repeat">
                        <div class="d-flex flex-column h-100 p-5 pb-3 text-shadow-1"><h4 class="pt-20 fw-bold">SSRF 1 </h4>
                          
                            <ul class="d-flex list-unstyled mt-auto">
                                <li class="me-auto">
                                    <img src="assets/aymax-partner.png" alt="Bootstrap" width="32" height="32">
                                    <h4 class="pt-15 fw-bold"> 1 pts </h4>
                                </li>
                                <li class="d-flex align-items-center me-3">
                                    <svg class="bi me-2" width="1em" height="1em">
                                        <use xlink:href="#geo-fill" />
                                    </svg>
                                    <input type="checkbox" id="checkbox19"
                                        onclick="updateBackground('card19', 'checkbox19')">&nbsp;<a class="pt-15 fw-bold" style="color:#ffffff;"
                                        href='labs/s0x01.php'>Access lab ></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="col">
                   <div class="card card-cover h-100 overflow-hidden text-white bg-dark rounded-5 shadow-lg"
                        id="card15"  height="10" style="background-image: url('assets/ssrff.png');background-repeat: no-repeat">
                        <div class="d-flex flex-column h-100 p-5 pb-3 text-shadow-1"><h4 class="pt-20 fw-bold">SSRF 2 </h4>
                            <h2 class="pt-5 mt-5 mb-4 display-6 lh-1 fw-bold"></h2>
                            <ul class="d-flex list-unstyled mt-auto">
                                <li class="me-auto">
                                
                                    <h4 class="pt-15 fw-bold"> 2 pts </h4>
                                </li>
                                <li class="d-flex align-items-center me-3">
                                    <svg class="bi me-2" width="1em" height="1em">
                                        <use xlink:href="#geo-fill" />
                                    </svg>
                                    <input type="checkbox" id="checkbox14"
                                        onclick="updateBackground('card14', 'checkbox14')">&nbsp;<a class="pt-15 fw-bold" style="color:#ffffff;"
                                        href='labs/s0x02.php'>Access lab ></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>

            <h1 class="h1-index">Other Attacks</h1>
            <!-- File upload -->
            <div class="row row-cols-1 row-cols-lg-3 align-items-stretch g-4 py-5">
                <div class="col">
                  <div class="card card-cover h-100 overflow-hidden text-white bg-dark rounded-5 shadow-lg"
                        id="card15"  height="10" style="background-image: url('assets/fileup.png');background-repeat: no-repeat">
                        <div class="d-flex flex-column h-100 p-5 pb-3 text-shadow-1"><h4 class="pt-20 fw-bold">File upload 1 </h4>
                            <h2 class="pt-5 mt-5 mb-4 display-6 lh-1 fw-bold"></h2>
                            <ul class="d-flex list-unstyled mt-auto">
                                <li class="me-auto">
                                    <img src="assets/aymax-partner.png" alt="Bootstrap" width="32" height="32">
                                    <h4 class="pt-15 fw-bold"> 1 pts </h4>
                                </li>
                                <li class="d-flex align-items-center me-3">
                                    <svg class="bi me-2" width="1em" height="1em">
                                        <use xlink:href="#geo-fill" />
                                    </svg>
                                    <input type="checkbox" id="checkbox10"
                                        onclick="updateBackground('card10', 'checkbox10')">&nbsp;<a class="pt-15 fw-bold" style="color:#ffffff;"
                                        href='labs/f0x01.php'>Access lab ></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="col">
                    <div class="card card-cover h-100 overflow-hidden text-white bg-dark rounded-5 shadow-lg"
                        id="card15"  height="10" style="background-image: url('assets/fileup.png');background-repeat: no-repeat">
                        <div class="d-flex flex-column h-100 p-5 pb-3 text-shadow-1"><h4 class="pt-20 fw-bold">File upload 2 </h4>
                            <h2 class="pt-5 mt-5 mb-4 display-6 lh-1 fw-bold"></h2>
                            <ul class="d-flex list-unstyled mt-auto">
                                <li class="me-auto">
                                    <img src="assets/aymax-partner.png" alt="Bootstrap" width="32" height="32">
                                    <h4 class="pt-15 fw-bold"> 2 pts </h4>
                                </li>
                                <li class="d-flex align-items-center me-3">
                                    <svg class="bi me-2" width="1em" height="1em">
                                        <use xlink:href="#geo-fill" />
                                    </svg>
                                    <input type="checkbox" id="checkbox11"
                                        onclick="updateBackground('card11', 'checkbox11')">&nbsp;<a class="pt-15 fw-bold" style="color:#ffffff;"
                                        href='labs/f0x02.php'>Access lab ></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="col">
                   <div class="card card-cover h-100 overflow-hidden text-white bg-dark rounded-5 shadow-lg"
                        id="card15"  height="10" style="background-image: url('assets/fileup.png');background-repeat: no-repeat">
                        <div class="d-flex flex-column h-100 p-5 pb-3 text-shadow-1"><h4 class="pt-20 fw-bold">File upload 3 </h4>
                            <h2 class="pt-5 mt-5 mb-4 display-6 lh-1 fw-bold"></h2>
                            <ul class="d-flex list-unstyled mt-auto">
                                <li class="me-auto">
                                    <img src="assets/aymax-partner.png" alt="Bootstrap" width="32" height="32">
                                     <h4 class="pt-15 fw-bold"> 3 pts </h4>
                                </li>
                                <li class="d-flex align-items-center me-3">
                                    <svg class="bi me-2" width="1em" height="1em">
                                        <use xlink:href="#geo-fill" />
                                    </svg>
                                    <input type="checkbox" id="checkbox12"
                                        onclick="updateBackground('card12', 'checkbox12')">&nbsp;<a class="pt-15 fw-bold" style="color:#ffffff;"
                                        href='labs/f0x03.php'>Access lab ></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <!-- CSRF -->
            <div class="row row-cols-1 row-cols-lg-3 align-items-stretch g-4 py-5">
                <div class="col">
                    <div class="card card-cover h-100 overflow-hidden text-white bg-dark rounded-5 shadow-lg"
                        id="card15"  height="10" style="background-image: url('assets/csrf.png');background-repeat: no-repeat">
                        <div class="d-flex flex-column h-100 p-5 pb-3 text-shadow-1"><h4 class="pt-20 fw-bold">CSRF 1 </h4>
                            <h2 class="pt-5 mt-5 mb-4 display-6 lh-1 fw-bold"></h2>
                            <ul class="d-flex list-unstyled mt-auto">
                                <li class="me-auto">
                                    <img src="assets/aymax-partner.png" alt="Bootstrap" width="32" height="32">
                                    <h4 class="pt-15 fw-bold"> 1 pts </h4>
                                </li>
                                <li class="d-flex align-items-center me-3">
                                    <svg class="bi me-2" width="1em" height="1em">
                                        <use xlink:href="#geo-fill" />
                                    </svg>
                                    <input type="checkbox" id="checkbox19"
                                        onclick="updateBackground('card19', 'checkbox19')">&nbsp;<a class="pt-15 fw-bold" style="color:#ffffff;"
                                        href='labs/csrf0x01.php'>Access lab ></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="col">
                   <div class="card card-cover h-100 overflow-hidden text-white bg-dark rounded-5 shadow-lg"
                        id="card15"  height="10" style="background-image: url('assets/csrf.png');background-repeat: no-repeat">
                        <div class="d-flex flex-column h-100 p-5 pb-3 text-shadow-1"><h4 class="pt-20 fw-bold">CSRF 2 </h4>
                            <h2 class="pt-5 mt-5 mb-4 display-6 lh-1 fw-bold"></h2>
                            <ul class="d-flex list-unstyled mt-auto">
                                <li class="me-auto">
                                    <img src="assets/aymax-partner.png" alt="Bootstrap" width="32" height="32">
                                    <h4 class="pt-15 fw-bold"> 2 pts </h4>
                                </li>
                                <li class="d-flex align-items-center me-3">
                                    <svg class="bi me-2" width="1em" height="1em">
                                        <use xlink:href="#geo-fill" />
                                    </svg>
                                    <input type="checkbox" id="checkbox14"
                                        onclick="updateBackground('card14', 'checkbox14')">&nbsp;<a class="pt-15 fw-bold" style="color:#ffffff;"
                                        href='labs/csrf0x02.php'>Access lab ></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="col">
                   <div class="card card-cover h-100 overflow-hidden text-white bg-dark rounded-5 shadow-lg"
                        id="card15"  height="10" style="background-image: url('assets/open.png');background-repeat: no-repeat">
                        <div class="d-flex flex-column h-100 p-5 pb-3 text-shadow-1"><h4 class="pt-20 fw-bold">Open redirect  1 </h4>
                            <h2 class="pt-5 mt-5 mb-4 display-6 lh-1 fw-bold"></h2>
                            <ul class="d-flex list-unstyled mt-auto">
                                <li class="me-auto">
                                    <img src="assets/aymax-partner.png" alt="Bootstrap" width="32" height="32">
                                     <h4 class="pt-15 fw-bold"> 2 pts </h4>
                                </li>
                                <li class="d-flex align-items-center me-3">
                                    <svg class="bi me-2" width="1em" height="1em">
                                        <use xlink:href="#geo-fill" />
                                    </svg>
                                    <input type="checkbox" id="checkbox19"
                                        onclick="updateBackground('card19', 'checkbox19')">&nbsp;<a class="pt-15 fw-bold" style="color:#ffffff;"
                                        href='labs/r0x01.php'>Access lab ></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <!-- SSRF -->
            <div class="row row-cols-1 row-cols-lg-3 align-items-stretch g-4 py-5">
                
                <div class="col">
                   <div class="card card-cover h-100 overflow-hidden text-white bg-dark rounded-5 shadow-lg"
                        id="card15"  height="10" style="background-image: url('assets/input.png');background-repeat: no-repeat">
                        <div class="d-flex flex-column h-100 p-5 pb-3 text-shadow-1"><h4 class="pt-15 fw-bold"> Input validation </h4>
                            <h2 class="pt-5 mt-5 mb-4 display-6 lh-1 fw-bold"></h2>
                            <ul class="d-flex list-unstyled mt-auto">
                                <li class="me-auto">
                                    <img src="assets/aymax-partner.png" alt="Bootstrap" width="32" height="32">
                                    <h4 class="pt-15 fw-bold"> 5 pts </h4>
                                </li>
                                <li class="d-flex align-items-center me-3">
                                    <svg class="bi me-2" width="1em" height="1em">
                                        <use xlink:href="#geo-fill" />
                                    </svg>
                                    <input type="checkbox" id="checkbox19"
                                        onclick="updateBackground('card19', 'checkbox19')">&nbsp;<a class="pt-15 fw-bold" style="color:#ffffff;"
                                        href='labs/iv0x01.php'>Access lab ></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>

            </div>
        </div>
        <div>
            <p class="small text-center">Don't forget to take regular breaks, you got this :)</p>
            <p class="small text-center">Practical  Labs  By Raed Guesmi</p>
        </div>
        <!-- instructions modal -->
        <div class="modal" id="instructionsModal" tabindex="-1" aria-labelledby="instructionsLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="instructionsModalLabel">Instructions</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <h2>Where to begin</h2>
                        <p>Watch the videos from the course, they will guide you through the labs and let you know
                            which ones are challenges.</p>
                        <p>This course and these labs are primarily focussed on helping you build practical skills.
                            Of
                            course we will provide theory and support along the way but hands-on practice is the
                            only
                            way to get good at BugBounty and Web Application Penetration Testing.</p>
                        <p>You're encouraged to test out other tools and scanners too as you go along!</p>
                        <p>I also encorage you to try out attacks you've learned on different labs (e.g. many of
                            them
                            are vulnerable to XSS, not just the XSS ones)</p>
                        <p>To reset the lab databases, visit /init.php</p>
                        <p>If you have issues, ping us a message on discord!</p>
                        <hr>
                        <p>Good luck!</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
        <!-- Existing content -->
      

  

        <!-- Button to reset and replay a0x01 -->
        <form action="index.php" method="post">
            <button type="submit" name="reset_challenge" class="btn btn-warning">Replay a0x01</button>
        </form>


        <!-- Existing content -->
    </div>
    
    </main>

    <script src="assets/popper.min.js"></script>
    <script src="assets/bootstrap.min.js"></script>

    <!-- some custom colours etc -->
    <style>
    .bg-green {
        background-color: #005e1c !important;
    }

    .bg-grey {
        background-color: #212529 !important;
    }
    </style>

    <script>
    window.onload = function() {
        for (let i = 1; i <= 19; i++) {
            if (localStorage.getItem('checkbox' + i) === 'true') {
                document.getElementById('checkbox' + i).checked = true;
                document.getElementById('card' + i).classList.add('bg-green');
            }
        }
    }

    function updateBackground(cardId, checkboxId) {
        var card = document.getElementById(cardId);
        var checkbox = document.getElementById(checkboxId);

        if (checkbox.checked == true) {
            card.classList.add('bg-green');
            card.classList.remove('bg-grey');
            localStorage.setItem(checkboxId, 'true');
        } else {
            card.classList.add('bg-grey');
            card.classList.remove('bg-green');
            localStorage.setItem(checkboxId, 'false');
        }
    }
    </script>

</body>

</html>
