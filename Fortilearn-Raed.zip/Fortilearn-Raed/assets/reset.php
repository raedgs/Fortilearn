<?php
require '../db.php';

// Check if the user is authorized to perform this action
session_start();
if (!isset($_SESSION['admin']) || !$_SESSION['admin']) {
    header('Location: index.php');
    exit;
}

// Function to reset the database
function resetDatabase($conn) {
    $queries = [
        "DROP TABLE IF EXISTS idor0x01",
        "DROP TABLE IF EXISTS auth0x03",
        "CREATE TABLE idor0x01 (id INT PRIMARY KEY, username VARCHAR(50), address VARCHAR(255), type VARCHAR(50))",
        "CREATE TABLE auth0x03 (username VARCHAR(50) PRIMARY KEY, password VARCHAR(255), lockout_count INT DEFAULT 0)",
        // Add other table creation queries as needed
    ];

    foreach ($queries as $query) {
        if ($conn->query($query) !== TRUE) {
            echo "Error: " . $conn->error;
            return false;
        }
    }
    return true;
}

// Reset database and labs
if (resetDatabase($conn)) {
    // Reset session score
    $_SESSION['score'] = 0;
    $_SESSION['completed_pages'] = [];

    echo "Database and labs have been reset successfully. <a href='index.php'>Go back to the main page</a>";
} else {
    echo "Failed to reset the database.";
}

$conn->close();
?>
